package application;

import javafx.scene.layout.VBox;
import javafx.scene.Node;
import javafx.scene.control.ListView;

public class Resources {

    public VBox showResourcesContent() {
        VBox resourcesLayout = new VBox();
        ListView<String> resourceList = new ListView<>();
        resourceList.getItems().addAll("Java Tutorial - Oracle", "Python Crash Course", "Machine Learning Guide", "Full Stack Development Roadmap");
        resourcesLayout.getChildren().add(resourceList);
        return resourcesLayout;
    }

    // Fixed getView method to return actual UI content
    public Node getView() {
        return showResourcesContent();  // Returns the layout from showResourcesContent
    }
}
