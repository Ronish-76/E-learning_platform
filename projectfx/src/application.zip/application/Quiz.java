package application;

import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.Node;
import javafx.scene.control.Button;

public class Quiz {

    public VBox showQuizContent() {
        VBox quizLayout = new VBox();

        Label questionLabel = new Label("What does UI stand for in the context of design?");
        ToggleGroup optionsGroup = new ToggleGroup();
        RadioButton option1 = new RadioButton("User Integration");
        RadioButton option2 = new RadioButton("User Interface");
        RadioButton option3 = new RadioButton("Universal Interaction");
        RadioButton option4 = new RadioButton("User Involvement");

        option1.setToggleGroup(optionsGroup);
        option2.setToggleGroup(optionsGroup);
        option3.setToggleGroup(optionsGroup);
        option4.setToggleGroup(optionsGroup);

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            RadioButton selectedOption = (RadioButton) optionsGroup.getSelectedToggle();
            if (selectedOption != null) {
                System.out.println("Selected: " + selectedOption.getText());
            }
        });

        quizLayout.getChildren().addAll(questionLabel, option1, option2, option3, option4, submitButton);
        return quizLayout;
    }

    // Fixed getView method to return actual UI content
    public Node getView() {
        return showQuizContent();  // Returns the layout from showQuizContent
    }
}
