package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class CoursesPage {

    // Modified getView to return the VBox
    public Node getView() {
        return getCoursesPage();  // Return the VBox from getCoursesPage
    }

    private VBox getCoursesPage() {
        VBox coursesPage = new VBox(20);
        coursesPage.setPadding(new Insets(20));
        coursesPage.setAlignment(Pos.CENTER);

        Label coursesLabel = new Label("Courses");
        coursesLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        ObservableList<String> courses = FXCollections.observableArrayList(
                "Java Programming",
                "Data Structures",
                "Machine Learning",
                "Web Development",
                "Cybersecurity",
                "Cloud Computing"
        );

        ListView<String> coursesListView = new ListView<>(courses);
        coursesListView.setPrefSize(400, 300);

        coursesPage.getChildren().addAll(coursesLabel, coursesListView);

        return coursesPage;
    }
}
