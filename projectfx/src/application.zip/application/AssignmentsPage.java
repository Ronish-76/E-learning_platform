package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class AssignmentsPage {

    public Node getView() {  // Fix: Return type changed to Node
        return getAssignmentsPage();
    }

    private VBox getAssignmentsPage() {
        VBox assignmentsPage = new VBox(20);
        assignmentsPage.setPadding(new Insets(20));
        assignmentsPage.setAlignment(Pos.CENTER);

        Label assignmentsLabel = new Label("Assignments");
        assignmentsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        TableView<Assignment> assignmentsTable = new TableView<>();
        assignmentsTable.setPrefWidth(400);  // Ensure it has enough space

        TableColumn<Assignment, String> assignmentNameColumn = new TableColumn<>("Assignment Name");
        assignmentNameColumn.setCellValueFactory(data -> data.getValue().assignmentNameProperty());
        assignmentNameColumn.setPrefWidth(200);  // Fix column width

        TableColumn<Assignment, String> dueDateColumn = new TableColumn<>("Due Date");
        dueDateColumn.setCellValueFactory(data -> data.getValue().dueDateProperty());
        dueDateColumn.setPrefWidth(200);  // Fix column width

        assignmentsTable.getColumns().addAll(assignmentNameColumn, dueDateColumn);

        assignmentsTable.getItems().addAll(
                new Assignment("Java Programming Assignment", "2025-03-15"),
                new Assignment("Data Structures Assignment", "2025-03-20")
        );

        assignmentsPage.getChildren().addAll(assignmentsLabel, assignmentsTable);

        return assignmentsPage;
    }

    public static class Assignment {
        private final StringProperty assignmentName;
        private final StringProperty dueDate;

        public Assignment(String assignmentName, String dueDate) {
            this.assignmentName = new SimpleStringProperty(assignmentName);
            this.dueDate = new SimpleStringProperty(dueDate);
        }

        public StringProperty assignmentNameProperty() {
            return assignmentName;
        }

        public StringProperty dueDateProperty() {
            return dueDate;
        }
    }
}
