package application;

import java.net.URL;

import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.*;

public class Dashboard_S extends Application {
    private BorderPane root;
    private VBox mainContent;
    private VBox leftSidebar;
    private boolean sidebarCollapsed = false;

    @Override
    public void start(Stage primaryStage) {
        root = new BorderPane();

        primaryStage.getIcons().add(new Image("file:C:/Users/HP/eclipse-workspace/projectfx/resources/app_icon.png"));

        // Left Sidebar    
        leftSidebar = createLeftSidebar();
        root.setLeft(leftSidebar);

        // Top Section (Header)
        HBox topSection = createTopSection();
        root.setTop(topSection);

        // Main Content Area
        mainContent = new VBox();
        mainContent.setPadding(new Insets(20));
        root.setCenter(mainContent);

        // Scene setup
        Scene scene = new Scene(root, 1200, 800);

        // Load CSS file (corrected path)
        URL cssUrl = getClass().getResource("/style.css"); 
        if (cssUrl != null) {
            scene.getStylesheets().add(cssUrl.toExternalForm());
        } else {
            System.out.println("CSS file not found");
        }

        primaryStage.setTitle("E-Learning Dashboard");
        primaryStage.setMaximized(true);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createLeftSidebar() {
        VBox sidebar = new VBox(2);
        sidebar.setId("sidebar");
        sidebar.setPadding(new Insets(1));
        sidebar.setStyle("-fx-background-color: #2c3e50;");

        Label menuTitle = new Label("MENU");
        menuTitle.getStyleClass().add("menu-title");

        Button homeBtn = createSidebarButton("Home", () -> mainContent.getChildren().setAll(new Label("Home Page")));
        Button coursesBtn = createSidebarButton("Courses", () -> mainContent.getChildren().setAll(new Label("Courses Page")));
        Button assignmentsBtn = createSidebarButton("Assignments", () -> mainContent.getChildren().setAll(new Label("Assignments Page")));
        Button progressBtn = createSidebarButton("Progress", () -> mainContent.getChildren().setAll(new Label("Progress Page")));
        Button resourcesBtn = createSidebarButton("Resources", () -> mainContent.getChildren().setAll(new Label("Resources Page")));
        Button quizBtn = createSidebarButton("Quiz", () -> mainContent.getChildren().setAll(new Label("Quiz Page")));
        Button profileBtn = createSidebarButton("Profile", () -> mainContent.getChildren().setAll(new Label("Profile Page")));
        Button toggleBtn = createSidebarButton("Toggle Sidebar", this::toggleSidebar);

        sidebar.getChildren().addAll(menuTitle, homeBtn, coursesBtn, assignmentsBtn, progressBtn, resourcesBtn, quizBtn, profileBtn, toggleBtn);
        return sidebar;
    }

    private Button createSidebarButton(String text, Runnable action) {
        Button button = new Button(text);
        button.setPrefWidth(200);
        button.getStyleClass().add("sidebar-button");
        button.setOnAction(_ -> action.run());
        return button;
    }

    private HBox createTopSection() {
        HBox topSection = new HBox();
        topSection.setPadding(new Insets(15));
        topSection.setStyle("-fx-background-color: #2980b9;");
        topSection.setAlignment(Pos.CENTER_LEFT);

        Label dashboardLabel = new Label("Dashboard");
        dashboardLabel.getStyleClass().add("dashboard-title");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        topSection.getChildren().addAll(dashboardLabel, spacer);
        return topSection;
    }

    private void toggleSidebar() {
        sidebarCollapsed = !sidebarCollapsed;
        if (sidebarCollapsed) {
            // Collapse Sidebar
            leftSidebar.setPrefWidth(50);
        } else {
            // Expand Sidebar
            leftSidebar.setPrefWidth(200);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
