package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ProgressPage {

    public Node getView() {  // Fix: Return type changed to Node
        return createProgressPage();
    }

    private VBox createProgressPage() {
        VBox progressLayout = new VBox(20);
        progressLayout.setPadding(new Insets(20));
        progressLayout.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Progress Statistics");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        VBox totalActivitySection = createTotalActivitySection();

        HBox statsCardsSection = createStatsCardsSection();

        progressLayout.getChildren().addAll(titleLabel, totalActivitySection, statsCardsSection);
        return progressLayout;
    }

    private VBox createTotalActivitySection() {
        VBox totalActivitySection = new VBox(10);
        totalActivitySection.setAlignment(Pos.CENTER);

        Label percentageLabel = new Label("64%");
        percentageLabel.setFont(Font.font("Arial", FontWeight.BOLD, 48));

        Label totalActivityLabel = new Label("Total Activity");
        totalActivityLabel.setFont(Font.font("Arial", 16));

        VBox progressBarSection = createProgressBar();

        totalActivitySection.getChildren().addAll(percentageLabel, totalActivityLabel, progressBarSection);
        return totalActivitySection;
    }

    private VBox createProgressBar() {
        VBox progressBarSection = new VBox(5);
        HBox progressBar = new HBox(0);

        double completed = 24;
        double inProgress = 35;
        double pending = 41;
        double total = completed + inProgress + pending;

        Rectangle completedRect = createSegment(completed / total, Color.PURPLE);
        Rectangle inProgressRect = createSegment(inProgress / total, Color.GREEN);
        Rectangle pendingRect = createSegment(pending / total, Color.ORANGE);

        progressBar.getChildren().addAll(completedRect, inProgressRect, pendingRect);

        progressBarSection.getChildren().add(progressBar);
        return progressBarSection;
    }

    private Rectangle createSegment(double percentage, Color color) {
        Rectangle rect = new Rectangle(percentage * 400, 10);  // Fixed width; could be adjusted for responsiveness
        rect.setFill(color);
        return rect;
    }

    private HBox createStatsCardsSection() {
        HBox statsCardsSection = new HBox(20);
        statsCardsSection.setAlignment(Pos.CENTER);

        VBox inProgressCard = createStatCard("In Progress", 8, Color.PURPLE);
        VBox completedCard = createStatCard("Completed", 12, Color.GREEN);
        VBox upcomingCard = createStatCard("Upcoming", 14, Color.ORANGE);

        statsCardsSection.getChildren().addAll(inProgressCard, completedCard, upcomingCard);
        return statsCardsSection;
    }

    private VBox createStatCard(String title, int value, Color color) {
        VBox statCard = new VBox(5);
        statCard.setAlignment(Pos.CENTER);

        Label iconLabel = new Label("\u23F0");
        iconLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        iconLabel.setTextFill(color);

        Label valueLabel = new Label(String.valueOf(value));
        valueLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Arial", 14));

        statCard.getChildren().addAll(iconLabel, valueLabel, titleLabel);
        return statCard;
    }
}
