package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class HomePage {

    public Node getView() {  // Fix: Now returns a valid JavaFX Node
        return getHomePage();
    }

    private VBox getHomePage() {
        VBox homePage = new VBox(20);
        homePage.setPadding(new Insets(20));
        homePage.setAlignment(Pos.CENTER);

        Label welcomeLabel = new Label("Welcome to the E-Learning Dashboard!");
        welcomeLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        Label description = new Label("Access your courses, track your progress, complete quizzes, and more!");
        description.setFont(Font.font("Arial", 18));

        homePage.getChildren().addAll(welcomeLabel, description);

        return homePage;
    }
}
