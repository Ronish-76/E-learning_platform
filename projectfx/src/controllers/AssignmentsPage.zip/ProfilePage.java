package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ProfilePage {

    public Node getView() {  // Fix: Now returns a valid JavaFX Node
        return getProfilePage();
    }

    private VBox getProfilePage() {
        VBox profilePage = new VBox(20);
        profilePage.setPadding(new Insets(20));
        profilePage.setAlignment(Pos.CENTER);

        Label profileLabel = new Label("User Profile");
        profileLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        Label userName = new Label("Name: John Doe");
        userName.setFont(Font.font("Arial", 18));

        Label userEmail = new Label("Email: john.doe@example.com");
        userEmail.setFont(Font.font("Arial", 18));

        profilePage.getChildren().addAll(profileLabel, userName, userEmail);

        return profilePage;
    }
}
