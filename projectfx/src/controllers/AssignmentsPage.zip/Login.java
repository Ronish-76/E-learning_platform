package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Login extends Application {

    @Override
    public void start(Stage primaryStage) {
        VBox leftPanel = new VBox(15);
        leftPanel.setPadding(new Insets(40));
        leftPanel.setAlignment(Pos.CENTER_LEFT);
        leftPanel.setStyle("-fx-background-color: #ffffff;");
        leftPanel.setMinWidth(400);

        Label logo = new Label("E-Learning");
        logo.setFont(Font.font("Inter", FontWeight.BOLD, 24));

        Label title = new Label("Log in to your account");
        title.setFont(Font.font("Inter", FontWeight.BOLD, 28));

        Label subtitle = new Label("Welcome back! Please enter your details.");
        subtitle.setFont(Font.font("Inter", FontWeight.NORMAL, 14));
        subtitle.setTextFill(Color.GRAY);

        Label emailLabel = new Label("Username");
        TextField emailField = new TextField();
        emailField.setPromptText("Enter your username");
        emailField.setMinHeight(40);

        Label passwordLabel = new Label("Password");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        passwordField.setMinHeight(40);

        Button loginButton = new Button("Log in");
        loginButton.setStyle("-fx-background-color: #000000; -fx-text-fill: #ffffff; -fx-font-weight: bold;");
        loginButton.setMinHeight(40);
        loginButton.setMaxWidth(Double.MAX_VALUE);
        
        loginButton.setOnAction(e -> validateForm(emailField, passwordField, primaryStage));

        Separator separator = new Separator();
        separator.setMaxWidth(Double.MAX_VALUE);

        Label signUpLink = new Label("Don't have an account? Sign up");
        signUpLink.setFont(Font.font("Inter", FontWeight.NORMAL, 14));
        signUpLink.setTextFill(Color.BLUE);
        signUpLink.setOnMouseClicked(e -> new Registration().start(primaryStage));

        leftPanel.getChildren().addAll(logo, title, subtitle, emailLabel, emailField, passwordLabel, passwordField, loginButton, separator, signUpLink);

        StackPane rightPanel = new StackPane();
        rightPanel.setStyle("-fx-background-color: #f9f9f9;");
        rightPanel.setMinWidth(700);

        ImageView imageView = new ImageView(new Image("file:C:/Users/HP/eclipse-workspace/projectfx/src/resources/LALA.png"));
        imageView.setFitWidth(700);
        imageView.setPreserveRatio(true);

        rightPanel.getChildren().add(imageView);

        HBox mainContainer = new HBox(leftPanel, rightPanel);

        Scene scene = new Scene(mainContainer, 1100, 700);
        primaryStage.setScene(scene);
        primaryStage.setWidth(1100);
        primaryStage.setHeight(700);
        primaryStage.centerOnScreen();
        primaryStage.setResizable(false); // Disable resizing and remove the fullscreen button
        primaryStage.setTitle("Log In");
        primaryStage.show();
    }

    private void validateForm(TextField username, PasswordField password, Stage primaryStage) {
        if (username.getText().trim().isEmpty() || password.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Missing Information", "Please enter both username and password.");
        } else {
            primaryStage.close();
            launchDashboard();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.show();
    }

    private void launchDashboard() {
        Dashboard_S dashboard = new Dashboard_S();
        Stage dashboardStage = new Stage();
        try {
            dashboard.start(dashboardStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
